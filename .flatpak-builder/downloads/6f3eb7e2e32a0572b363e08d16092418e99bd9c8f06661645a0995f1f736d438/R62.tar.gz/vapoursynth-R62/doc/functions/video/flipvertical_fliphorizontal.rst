FlipVertical/FlipHorizontal
===========================

.. function:: FlipVertical(vnode clip)
              FlipHorizontal(vnode clip)
   :module: std

   Flips the *clip* in the vertical or horizontal direction.
