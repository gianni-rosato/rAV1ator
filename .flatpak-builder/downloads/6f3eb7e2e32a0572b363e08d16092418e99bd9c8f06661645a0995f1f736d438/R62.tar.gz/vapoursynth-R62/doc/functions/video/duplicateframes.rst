DuplicateFrames
===============

.. function:: DuplicateFrames(vnode clip, int[] frames)
   :module: std

   Duplicates the specified frames.

   A frame may be duplicated several times.

   All frame numbers apply to the input clip.
