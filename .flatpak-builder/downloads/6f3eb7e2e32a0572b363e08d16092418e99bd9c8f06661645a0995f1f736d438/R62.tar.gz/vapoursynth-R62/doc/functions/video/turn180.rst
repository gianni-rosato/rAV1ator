Turn180
=======

.. function:: Turn180(vnode clip)
   :module: std

   Turns the frames in a clip 180 degrees (to the left, not to the right).
