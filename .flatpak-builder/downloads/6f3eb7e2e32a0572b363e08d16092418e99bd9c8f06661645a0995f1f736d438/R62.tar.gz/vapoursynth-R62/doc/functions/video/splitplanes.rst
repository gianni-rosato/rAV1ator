SplitPlanes
===========

.. function::   SplitPlanes(vnode clip)
   :module: std

   SplitPlanes returns each plane of the input as
   separate clips.
